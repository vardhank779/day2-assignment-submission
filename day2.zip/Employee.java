package com.employee;

public class Employee {
         String name,city;
         int age;

        public void display(){

            System.out.println("The name is "+name);
            System.out.println("The city is "+city);
            System.out.println("The age is "+age);

        }
}
