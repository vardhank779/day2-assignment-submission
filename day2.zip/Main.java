package com.employee;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Employee e1=new Employee();
        e1.name="pooja";
        e1.age=20;
        e1.city="Seoul";
        e1.display();


        Employee e2=new Employee();
        e2.name=("harsha");
        e2.age=20;
        e2.city="bangalore";
        e2.display();

    }
}
